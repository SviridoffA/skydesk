#!/usr/local/bin/php -q
<?php
function run($cmd) {
  $pp=popen($cmd,"r");
  $str = fread($pp, 100000);
  pclose($pp);
  return($str);
}
function savetable($table) {
  $str="/usr/local/bin/mysqldump -p#fdnjvfn45 mvs $table> /var/backup/$d/$table.sql";
  $res=run($str);
  if (strlen($res) > 5) {
    $str="$d sql dump table $table failed\n"; 
    $fp=fopen("/var/log/backup.log","a");
    fputs($fp,$str); 
    fclose($fp);
  }
  return($res);
}

$d=date("Ymd");
mkdir("/var/backup/$d",0700);
copy("/etc/ppp/chap-secrets","/var/backup/$d/chap-secrets");
copy("/usr/local/apache/servers/statmvs.mariupol.net/boss","/var/backup/$d/boss");
copy("/etc/rc.conf","/var/backup/$d/rc.conf");
copy("/usr/local/etc/ipa.conf","/var/backup/$d/ipa.conf");
copy("/etc/firewall/firewall.net","/var/backup/$d/firewall.net");
copy("/usr/local/apache/servers/statmvs.mariupol.net/auth","/var/backup/$d/auth");
savetable("begstat");
savetable("customers");
savetable("deklar");
savetable("dogovor");
savetable("payment");
savetable("pricelist");
savetable("site_faq");
savetable("site_news");
savetable("site_request");
savetable("site_special");
savetable("summary");
savetable("usercontrol");
savetable("sessions");
savetable("data");

$str="/usr/local/bin/mysqldump -p#fdnjvfn45 mvs > /var/backup/$d/mvs.sql";
$res=run($str);
if (strlen($res) > 5) {
  $str="$d sql dump failed\n"; 
  $fp=fopen("/var/log/backup.log","a");
  fputs($fp,$str); 
  fclose($fp);
}
$str="gzip /var/backup/$d/mvs.sql";
$res=run($str);
if (strlen($res) > 5) {
  $str="$d sql dump gzip failed\n"; 
  $fp=fopen("/var/log/backup.log","a");
  fputs($fp,$str); 
  fclose($fp);
}
?>