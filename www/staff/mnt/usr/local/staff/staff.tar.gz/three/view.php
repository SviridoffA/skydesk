<?php
require_once("cd.php");
mysql_connect("localhost","root","#fdnjvfn45");

$query="SELECT * FROM ".$table." ORDER BY cleft ASC"; 
$result=$dbh->query($query); 
while($row = $dbh->fetch_array($result)) 
{ 
   echo str_repeat("&nbsp;",6*$row['clevel']).$row['title']."<br>"; 
} 
?> 