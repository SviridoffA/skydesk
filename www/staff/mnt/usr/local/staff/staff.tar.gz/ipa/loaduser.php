#!/usr/local/bin/php -q
<?php
set_time_limit(0);
mysql_connect("localhost","root","#fdnjvfn45");
include_once('/usr/local/staff/ipa/read.inc');
$days=2;
$query="select year(subdate(now(), interval $days day)) as y,month(subdate(now(),interval $days  day)) as m,dayofmonth(subdate(now(), interval $days day)) as d from customers";
$res=mysql("mvs",$query);
echo mysql_error();
$sd=sprintf("%04d",mysql_result($res,0,"y")).".".sprintf("%02d",mysql_result($res,0,"m")).".".sprintf("%02d",mysql_result($res,0,"d"));
echo $sd;
// exit;
$query="select * from customers";
$res=mysql("mvs",$query);
echo mysql_error();
$num=mysql_num_rows($res);
// $sd="2002.12.01";
for ($i=0;$i < $num;$i++) {
  $username=mysql_result($res,$i,"username");
//   echo $username."\n";
  readdata($username,$username,$sd,date("Y.m.d"));
  readdata($username,$username."_chat",$sd,date("Y.m.d"));
  readdata($username,$username."_game",$sd,date("Y.m.d"));

}

?>