#!/usr/local/bin/php -q
<?php
$cmd="/sbin/ifconfig | /usr/bin/grep ppp | /usr/bin/grep UP | /usr/bin/cut -d \":\" -f1";
$pp=popen($cmd,"r");
$count=0;
while (!feof($pp)) {
   $str=trim(fgets($pp,1024));
//   echo $str;
   if ($str) {
     if ($count) {
       $query=$query." and interface not like '$str'";
       $query1=$query1." and interface not like '$str'";
     } else {
       $query="select * from users where interface not like '$str'";
       $query1="delete from  users where interface not like '$str'";
     }
   }
   $count++;
}
mysql_connect("localhost","root","#fdnjvfn45");
$res=mysql("mvs",$query);
$res1=mysql("mvs",$query1);
$num=mysql_num_rows($res);
if ($num) {
  for ($i=0;$i < $num;$i++) {
     $int=mysql_result($res,$i,"interface");
     echo "$int\n";
  }
}
// echo $query1;
?>