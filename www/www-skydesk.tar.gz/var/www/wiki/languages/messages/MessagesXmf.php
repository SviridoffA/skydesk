<?php
/** Mingrelian (მარგალური)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Alsandro
 * @author Andrijko Z.
 * @author Dato deutschland
 * @author Dawid Deutschland
 * @author Kaganer
 * @author Kilavagora
 * @author Lika2672
 * @author Machirkholi
 * @author Malafaya
 * @author Reedy
 * @author გიორგიმელა
 */

$fallback = 'ka';

