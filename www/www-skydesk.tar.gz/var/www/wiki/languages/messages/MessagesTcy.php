<?php
/** Tulu (ತುಳು)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author NamwikiTL
 * @author VASANTH S.N.
 * @author VinodSBangera
 */

$fallback = 'kn';

