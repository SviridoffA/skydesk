<?php
/** Kazakh (қазақша)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

# Stub message file for converter code "kk"

$fallback = 'kk-cyrl';

