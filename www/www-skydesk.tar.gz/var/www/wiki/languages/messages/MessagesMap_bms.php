<?php
/** Basa Banyumasan (Basa Banyumasan)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Bawoor
 * @author Slamet Serayu (on map-bms.wikipedia.org)
 * @author StefanusRA
 * @author לערי ריינהארט
 */

$fallback = 'jv, id';

