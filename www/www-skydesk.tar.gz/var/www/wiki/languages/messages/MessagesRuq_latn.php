<?php
/** Megleno-Romanian (Latin script) (Vlăheşte)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Andrijko Z.
 * @author Кумулај Маркус
 * @author Макѕе
 * @author Приетен тев
 */

$fallback = 'ro';

