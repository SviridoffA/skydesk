<?php
/** Tok Pisin (Tok Pisin)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author BarkingFish
 * @author Caffelice (on tpi.wikipedia.org)
 * @author Iketsi
 * @author Wantok
 * @author Wytukaze
 * @author לערי ריינהארט
 */

$namespaceNames = array(
	NS_SPECIAL          => 'Sipesol',
	NS_TALK             => 'Toktok',
	NS_USER             => 'Yusa',
	NS_USER_TALK        => 'Toktok_bilong_yusa',
	NS_PROJECT_TALK     => '$1_toktok',
	NS_FILE             => 'Fail',
	NS_FILE_TALK        => 'Toktok_bilong_fail',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'Toktok_bilong_mediawiki',
	NS_TEMPLATE         => 'Templet',
	NS_TEMPLATE_TALK    => 'Toktok_bilong_templet',
	NS_HELP             => 'Halivim',
	NS_HELP_TALK        => 'Toktok_bilong_halivim',
	NS_CATEGORY         => 'Grup',
	NS_CATEGORY_TALK    => 'Toktok_bilong_grup',
);

$specialPageAliases = array(
	'Confirmemail'              => array( 'Orait long imel' ),
	'Contributions'             => array( 'Ol senis bilong yusa' ),
	'CreateAccount'             => array( 'Mekim nupela login' ),
	'Emailuser'                 => array( 'Imel yusa' ),
	'Preferences'               => array( 'Ol laik bilong mi' ),
	'Randompage'                => array( 'Soim wanpela pes' ),
	'Recentchanges'             => array( 'Nupela senis' ),
	'Specialpages'              => array( 'Sipesol pes' ),
	'Upload'                    => array( 'Salim media fail' ),
	'Userlogin'                 => array( 'Yusa login' ),
	'Userlogout'                => array( 'Yusa logaut' ),
	'Watchlist'                 => array( 'Lukautbuk' ),
	'Whatlinkshere'             => array( 'Ol link ikam long hia' ),
);

