<?php
/** Tajik (Тоҷикӣ)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 * @comment falls back to Tajik (Cyrillic)
 *
 */

$fallback = 'tg-cyrl';
