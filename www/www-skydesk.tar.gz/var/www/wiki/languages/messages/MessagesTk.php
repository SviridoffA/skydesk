<?php
/** Turkmen (Türkmençe)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Amire80
 * @author Cekli829
 * @author Flrn
 * @author Hanberke
 * @author Kaganer
 * @author Reedy
 * @author Runningfridgesrule
 * @author The Evil IP address
 */

$namespaceNames = array(
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Ýörite',
	NS_TALK             => 'Çekişme',
	NS_USER             => 'Ulanyjy',
	NS_USER_TALK        => 'Ulanyjy_çekişme',
	NS_PROJECT_TALK     => '$1_çekişme',
	NS_FILE             => 'Faýl',
	NS_FILE_TALK        => 'Faýl_çekişme',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_çekişme',
	NS_TEMPLATE         => 'Şablon',
	NS_TEMPLATE_TALK    => 'Şablon_çekişme',
	NS_HELP             => 'Ýardam',
	NS_HELP_TALK        => 'Ýardam_çekişme',
	NS_CATEGORY         => 'Kategoriýa',
	NS_CATEGORY_TALK    => 'Kategoriýa_çekişme',
);

$linkTrail = '/^([a-zÄäÇçĞğŇňÖöŞşÜüÝýŽž]+)(.*)$/sDu';

