<?php
/** Sango (Sängö)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Ice201 (on sg.wikipedia.org)
 * @author Mdkidiri
 */

$fallback = 'fr';

// Remove French aliases
$namespaceGenderAliases = array();

