<?php
/** Chinese (China) (‪中文(中国大陆)‬)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Liangent
 * @author PhiLiP
 * @author Shizhao
 * @author Wong128hk
 * @author Xiaomingyan
 */

# Inherit everything for now
$fallback = 'zh-hans';

