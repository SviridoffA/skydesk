<?php
/** Khowar (کھوار)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'ur';
$rtl = true;

$namespaceNames = array(
	NS_MAIN             => '',
	NS_MEDIA            => 'میڈیا',
	NS_SPECIAL          => 'خاص',
	NS_TALK             => 'مشقولگی',
	NS_USER             => 'ممبار/یوزر',
);

