<?php
/**
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 */

$rtl = true;
