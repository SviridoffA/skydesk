<?php
/** Western Punjabi (پنجابی)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Arslan
 * @author Kaganer
 * @author Khalid Mahmood
 * @author Rachitrali
 * @author Reedy
 * @author ZaDiak
 */

$linkPrefixExtension = true;
$fallback8bitEncoding = 'windows-1256';

$rtl = true;

