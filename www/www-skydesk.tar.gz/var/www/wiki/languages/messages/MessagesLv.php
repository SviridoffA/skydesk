<?php
/** Latvian (latviešu)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Admresdeserv.
 * @author Dark Eagle
 * @author Edgars2007
 * @author FnTmLV
 * @author Geimeris
 * @author Geitost
 * @author Gleb Borisov
 * @author GreenZeb
 * @author Kaganer
 * @author Karlis
 * @author Kikos
 * @author Knakts
 * @author Marozols
 * @author Papuass
 * @author Reedy
 * @author Srolanh
 * @author Xil
 * @author Yyy
 * @author לערי ריינהארט
 */

/**
 * @copyright Copyright © 2006, Niklas Laxström
 * @license http://www.gnu.org/copyleft/gpl.html GNU General Public License 2.0 or later
 */

$namespaceNames = array(
	NS_MEDIA            => 'Media',
	NS_SPECIAL          => 'Special',
	NS_TALK             => 'Diskusija',
	NS_USER             => 'Lietotājs',
	NS_USER_TALK        => 'Lietotāja_diskusija',
	NS_PROJECT_TALK     => '{{grammar:ģenitīvs|$1}}_diskusija',
	NS_FILE             => 'Attēls',
	NS_FILE_TALK        => 'Attēla_diskusija',
	NS_MEDIAWIKI        => 'MediaWiki',
	NS_MEDIAWIKI_TALK   => 'MediaWiki_diskusija',
	NS_TEMPLATE         => 'Veidne',
	NS_TEMPLATE_TALK    => 'Veidnes_diskusija',
	NS_HELP             => 'Palīdzība',
	NS_HELP_TALK        => 'Palīdzības_diskusija',
	NS_CATEGORY         => 'Kategorija',
	NS_CATEGORY_TALK    => 'Kategorijas_diskusija',
);
$separatorTransformTable = array( ',' => "\xc2\xa0", '.' => ',' );

