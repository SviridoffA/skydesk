<?php
/** British English (British English)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$specialPageAliases = array(
	'Uncategorizedcategories'   => array( 'UncategorisedCategories' ),
	'Uncategorizedimages'       => array( 'UncategorisedFiles', 'UncategorisedImages' ),
	'Uncategorizedpages'        => array( 'UncategorisedPages' ),
	'Uncategorizedtemplates'    => array( 'UncategorisedTemplates' ),
);

