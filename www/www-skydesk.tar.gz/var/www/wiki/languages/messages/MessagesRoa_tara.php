<?php
/** tarandíne (tarandíne)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Joetaras
 * @author Kaganer
 * @author McDutchie
 * @author Reder
 */

$specialPageAliases = array(
	'Allmessages'               => array( 'TutteLeMessagge' ),
	'Preferences'               => array( 'Preferenze' ),
	'Recentchanges'             => array( 'UrtemeCangiaminde' ),
	'Statistics'                => array( 'Statisteche' ),
	'Upload'                    => array( 'Carecaminde' ),
	'Version'                   => array( 'Versione' ),
	'Watchlist'                 => array( 'PàggeneCondrollete' ),
);

