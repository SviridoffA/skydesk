<?php
/** ‪Chinese (Malaysia)‬ (‪中文(马来西亚)‬)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

# Inherit everything for now
$fallback = 'zh-sg, zh-hans';
