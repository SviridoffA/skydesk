<?php
/** Extremaduran (estremeñu)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$namespaceNames = array(
	NS_TEMPLATE         => 'Prantilla',
);

