<?php
/** Moldavian (молдовеняскэ)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 * @author Comp1089
 * @author Node ue
 * @author לערי ריינהארט
 */

$fallback = 'ro';

$specialPageAliases = array(
	'CreateAccount'             => array( 'КреареКонт' ),
	'Preferences'               => array( 'Преферинце' ),
	'Recentchanges'             => array( 'Модификэрьреченте' ),
);

