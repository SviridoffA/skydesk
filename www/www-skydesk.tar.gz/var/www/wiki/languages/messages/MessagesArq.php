<?php
/** Algerian Spoken Arabic (جزائري)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$digitTransformTable = array();

$separatorTransformTable = array(
	'.' => ',',
	',' => '.'
);

$fallback = 'ar';

