<?php
/** Fulah (Fulfulde)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'fr';

// Remove French aliases
$namespaceGenderAliases = array();

