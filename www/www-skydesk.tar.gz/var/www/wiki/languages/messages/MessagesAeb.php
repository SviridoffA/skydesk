<?php
/** Tunisian Spoken Arabic (   زَوُن)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$fallback = 'ar';

$rtl = true;

