<?php
/** Kazakh (China) (‫قازاقشا (جۇنگو)‬)
 *
 * To improve a translation please visit https://translatewiki.net
 *
 * @ingroup Language
 * @file
 *
 */

$rtl = true;

# Inherit everything for now
$fallback = 'kk-arab, kk-cyrl';
